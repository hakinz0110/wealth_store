import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default Firebase configuration options for different platforms
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return web; // Fallback to web for Windows
      case TargetPlatform.linux:
        return web; // Fallback to web for Linux
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not available for this platform.',
        );
    }
  }

  /// Firebase options for Web platform
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "AIzaSyDs_rdfPrzGVLkcnYgRfAD3s-Enkyrdb68",
    authDomain: "wealth-store-149c2.firebaseapp.com",
    projectId: "wealth-store-149c2",
    storageBucket: "wealth-store-149c2.firebasestorage.app",
    messagingSenderId: "936758655920",
    appId: "1:936758655920:web:d3d6b0874ae7e02d4df475",
    measurementId: "G-F9XT853M08",
  );

  /// Firebase options for Android
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: "AIzaSyDs_rdfPrzGVLkcnYgRfAD3s-Enkyrdb68",
    appId: "1:936758655920:android:1e958801b8e6757dd4f475",
    messagingSenderId: "936758655920",
    projectId: "wealth-store-149c2",
    storageBucket: "wealth-store-149c2.firebasestorage.app",
  );

  /// Firebase options for iOS
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: "AIzaSyDs_rdfPrzGVLkcnYgRfAD3s-Enkyrdb68",
    appId: "1:936758655920:ios:1e958801b8e6757dd4f475",
    messagingSenderId: "936758655920",
    projectId: "wealth-store-149c2",
    storageBucket: "wealth-store-149c2.firebasestorage.app",
    iosBundleId: "com.wealth.app.wealth_store",
  );

  /// Firebase options for macOS
  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: "AIzaSyDs_rdfPrzGVLkcnYgRfAD3s-Enkyrdb68",
    appId: "1:936758655920:macos:1e958801b8e6757dd4f475",
    messagingSenderId: "936758655920",
    projectId: "wealth-store-149c2",
    storageBucket: "wealth-store-149c2.firebasestorage.app",
    iosBundleId: "com.wealth.app.wealth_store",
  );
}
